// /* 1.
// a. undefined
// b. null
// c. 11
// d. 2
// e. [3, 19, 5, 6, 7, 8, 9, 10, 11, 12, 13]
// f. 8*/

// //2. SUBA NUM ÔNABUS EM MARROCOS, 27

// //1.
// let nome = prompt(`Insira seu nome`)
// let email = prompt(`Insira seu email`)

// alert(`O email ${email.trim().toLowerCase()} foi cadastrado com sucesso. Seja bem-vinda(o), ${nome}`)
// console.log(`O email ${email.trim().toLowerCase()} foi cadastrado com sucesso. Seja bem-vinda(o), ${nome}`)

// //2.
// let favFood = [`Pizza`, `Strogonoff`, `Lasanha`, `Hamburgúer`, `Massa`]
// console.log(favFood)

// console.log(`Essas são minhas comidas favoritas: \n${favFood[0]}  \n${favFood[1]}  \n${favFood[2]}  \n${favFood[3]}  \n${favFood[4]}`)

// let newFood = prompt(`Insira uma nova comida preferida`)
// favFood[1] = newFood
// console.log(`Sua nova lista de comidas preferidas é ${favFood}`)

// //3

// let tarefas = []

// let primeiraTarefa = prompt(`Insira sua primeira tarefa: `)
// let secTarefa = prompt(`Insira sua segunda tarefa: `)
// let thirdTarefa = prompt(`Insira sua terceira tarefa: `)

// tarefas = [primeiraTarefa, secTarefa, thirdTarefa]
// console.log(`Sua lista de tarefas é ${tarefas}`)

// let realizado = Number(prompt(`Insira o índice da tarefa que você já realizou `))
// tarefas.pop(realizado)

// console.log(`Sua nova lista de tarefas é ${tarefas}`)

//1. Desafio
//Não sei como fazer só com o que a gente aprendeu, ou eu só não sei
let lista = []
let frase = prompt(`Insira uma frase`)
lista = [frase]
console.log(frase.join(", "))

//2. Desafio
//Where's for?
let listaFruit = ["Banana", "Morango", "Abacaxi", "Laranja", "Ameixa"]

if (listaFruit[0].includes(`Abacaxi`) === true) {
    console.log(`O índice de Abacaxi é 0`)
} else if (listaFruit[1].includes(`Abacaxi`) === true){
    console.log(`O índice de Abacaxi é 1`)
} else if (listaFruit[2].includes(`Abacaxi`) === true) {
    console.log(`O índice de Abacaxi é 2`)
} else if (listaFruit[3].includes(`Abacaxi`) === true) {
    console.log(`O índice de Abacaxi é 3`)
} else {
    console.log(`O índice de Abacaxi é 4`)
}

console.log(`Seu tamanho de array é ${listaFruit.length}`)